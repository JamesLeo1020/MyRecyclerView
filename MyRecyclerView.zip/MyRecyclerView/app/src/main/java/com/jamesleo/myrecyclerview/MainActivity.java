package com.jamesleo.myrecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvHeroes;
	    private ArrayList<Hero> list = new ArrayList<>();

        	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
        	        super.onCreate(savedInstanceState);
        	        setContentView(R.layout.activity_main);

        	        rvHeroes = findViewById(R.id.rv_heroes);
        	        rvHeroes.setHasFixedSize(true);

        	        list.addAll(HeroesData.getListData());
        	        showRecyclerList();
        	    }

            private void showRecyclerList(){
        	        rvHeroes.setLayoutManager(new LinearLayoutManager(this));
        	        ListHeroAdapter listHeroAdapter = new ListHeroAdapter(list);
                rvHeroes.setAdapter(listHeroAdapter);
        	    }
		}
